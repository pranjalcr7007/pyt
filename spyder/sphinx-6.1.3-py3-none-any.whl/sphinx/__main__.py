"""The Sphinx documentation toolchain."""

from sphinx.cmd.build import main

raise SystemExit(main())
