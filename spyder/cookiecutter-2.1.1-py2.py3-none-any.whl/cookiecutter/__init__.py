"""Main package for Cookiecutter."""
__version__ = "2.1.1"
